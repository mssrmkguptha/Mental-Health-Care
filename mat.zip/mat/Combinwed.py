# ---------------------- DataCleaning.py ----------------------
import pandas as pd
import numpy as np
import warnings

warnings.filterwarnings('ignore')

# Load the dataset
df = pd.read_csv(r"C:\Users\DELL\OneDrive\Desktop\Mental_Health_Care_in_the_Last_4_Weeks.csv", encoding = 'ISO-8859-1')

# Display first few rows
print("First 5 rows of the dataset:\n", df.head())

# Display basic info about the dataset
print("\nDataset Info:\n")
df.info()

# Step 1: Handling Missing Values
print("\nMissing values in each column:\n", df.isnull().sum())
threshold = len(df) * 0.5
df_cleaned = df.dropna(thresh=threshold, axis=1)

for col in df_cleaned.select_dtypes(include='object').columns:
    df_cleaned[col] = df_cleaned[col].fillna(df_cleaned[col].mode()[0])

for col in df_cleaned.select_dtypes(include=['int64', 'float64']).columns:
    df_cleaned[col] = df_cleaned[col].fillna(df_cleaned[col].mean())

# Step 2: Remove Duplicates
df_cleaned = df_cleaned.drop_duplicates()

# Step 3: Standardize Column Names
df_cleaned.columns = df_cleaned.columns.str.strip().str.lower().str.replace(' ', '_')

# Step 5: Save Cleaned Data
df_cleaned.to_csv("cleaned_mental_health_data.csv", index=False)
print("\nData cleaning complete. Cleaned data saved to 'cleaned_mental_health_data.csv'")


# ---------------------- Testing.py ----------------------
import seaborn as sns
import matplotlib.pyplot as plt
from scipy import stats
from scipy.stats import chi2_contingency, shapiro
import statsmodels.api as sm
from datetime import datetime
warnings.filterwarnings("ignore")

# Reload cleaned data
df = pd.read_csv("cleaned_mental_health_data.csv")

print("Basic Descriptive Statistics:\n")
print(df['value'].describe())

print("\nMean and Std by Sex:\n")
print(df[df['group'] == 'By Sex'].groupby('subgroup')['value'].agg(['mean', 'std']))

print("\nMean by Age Group:\n")
print(df[df['group'] == 'By Age'].groupby('subgroup')['value'].mean())

# Independent T-test
sex_df = df[df['group'] == 'By Sex']
male_values = sex_df[sex_df['subgroup'] == 'Male']['value']
female_values = sex_df[sex_df['subgroup'] == 'Female']['value']

t_stat, p_val = stats.ttest_ind(male_values, female_values, nan_policy='omit')
print("\nndependent T-Test (Male vs Female):")
print(f"T-statistic = {t_stat:.4f}, p-value = {p_val:.4f}")

# Extended Descriptive Stats
print("\n Descriptive Statistics (Whole Dataset):\n")
print(df.describe())

print("\n Variance:\n", df.var(numeric_only=True))
print("\n Skewness:\n", df.skew(numeric_only=True))
print("\n Kurtosis:\n", df.kurt(numeric_only=True))

# Frequency Tables
print("\n Frequency Tables:\n")
categorical_cols = df.select_dtypes(include='object').columns
for col in categorical_cols:
    print(f"\n {col} value counts:")
    print(df[col].value_counts())

# Chi-Square Test
cat1 = categorical_cols[0]
cat2 = categorical_cols[1]

contingency_table = pd.crosstab(df[cat1], df[cat2])
chi2, p, dof, expected = chi2_contingency(contingency_table)
print(f"\n Chi-Square Test between '{cat1}' and '{cat2}':")
print(f"Chi2 = {chi2:.2f}, p-value = {p:.4f}")
print("=> Significant relationship " if p < 0.05 else "=> No significant relationship ")

# T-Test for binary categories
binary_cat = [col for col in categorical_cols if df[col].nunique() == 2]
if binary_cat:
    test_col = binary_cat[0]
    numeric_col = df.select_dtypes(include=['int64', 'float64']).columns[0]
    group1 = df[df[test_col] == df[test_col].unique()[0]][numeric_col]
    group2 = df[df[test_col] == df[test_col].unique()[1]][numeric_col]
    t_stat, p_val = stats.ttest_ind(group1, group2)
    print(f"\n📎 T-Test on '{numeric_col}' by '{test_col}' groups:")
    print(f"t-statistic = {t_stat:.2f}, p-value = {p_val:.4f}")
    print("=> Statistically significant difference " if p_val < 0.05 else "=> No statistically significant difference ")

# Correlation Heatmap
correlation_matrix = df.select_dtypes(include=['int64', 'float64', 'float']).corr()
print("\n Correlation Matrix:\n", correlation_matrix)

plt.figure(figsize=(10, 6))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt='.2f', linewidths=0.5)
plt.title("Correlation Heatmap")
plt.tight_layout()
plt.show()


# ---------------------- Visualization.py ----------------------
# Reload data again
df = pd.read_csv("cleaned_mental_health_data.csv")

sex_data = df[df['group'] == 'By Sex']
age_data = df[df['group'] == 'By Age']
national_data = df[df['group'] == 'National Estimate']

latest_period = sex_data['time_period'].max()
sex_latest = sex_data[sex_data['time_period'] == latest_period]
sex_values = sex_latest.groupby('subgroup')['value'].mean()

plt.figure(figsize=(5, 5))
plt.pie(sex_values, labels=sex_values.index, autopct='%1.1f%%')
plt.title('Sex Distribution of Mental Health Medication Usage')
plt.show()

plt.figure(figsize=(7, 5))
sns.violinplot(data=sex_data, x='subgroup', y='value')
plt.title('Mental Health Care Percentage by Sex (Violin Plot)')
plt.show()

top_ages = age_data.groupby('subgroup')['value'].mean().sort_values(ascending=False).head(5)
plt.figure(figsize=(7, 5))
sns.barplot(x=top_ages.index, y=top_ages.values)
plt.title('Top 5 Age Groups by Mental Health Medication Usage')
plt.ylabel('Percentage')
plt.xlabel('Age Group')
plt.show()

pivot_data = sex_data.pivot_table(index='time_period', columns='subgroup', values='value')
pivot_data.plot(kind='bar', stacked=True, figsize=(10, 6), title='Mental Health Care by Sex Over Time')
plt.ylabel('Percentage')
plt.show()

plt.figure(figsize=(5, 5))
plt.pie(sex_values, labels=sex_values.index, autopct='%1.1f%%')
centre_circle = plt.Circle((0, 0), 0.70, fc='white')
plt.gca().add_artist(centre_circle)
plt.title('Donut Chart – Sex Distribution')
plt.show()

overall_by_time = national_data.groupby('time_period')['value'].mean()
plt.figure(figsize=(10, 5))
plt.plot(overall_by_time.index, overall_by_time.values, marker='o')
plt.xticks(rotation=45)
plt.title('Total Mental Health Medication Use Over Time')
plt.ylabel('Percentage')
plt.tight_layout()
plt.show()

top_states = df.groupby('state')['value'].mean().sort_values(ascending=False).head(5)
plt.figure(figsize=(7, 5))
sns.barplot(x=top_states.index, y=top_states.values)
plt.title('Top 5 States by Mental Health Medication Usage')
plt.ylabel('Percentage')
plt.xlabel('State')
plt.show()

plt.figure(figsize=(7, 5))
sns.histplot(data=age_data, x='value', bins=10, kde=True)
plt.title('Histogram – Age Distribution of Mental Health Care')
plt.xlabel('Percentage')
plt.show()

plt.figure(figsize=(10, 6))
sns.scatterplot(data=age_data, x='time_period', y='value', hue='subgroup')
plt.xticks(rotation=45)
plt.title('Scatter Plot – Time vs Value by Age Group')
plt.tight_layout()
plt.show()

plt.figure(figsize=(7, 5))
sns.boxplot(data=sex_data, x='subgroup', y='value')
plt.title('Box Plot – Mental Health Care by Sex')
plt.ylabel('Percentage')
plt.xlabel('Sex')
plt.show()

numeric_df = df.select_dtypes(include='number')
correlation = numeric_df.corr()
plt.figure(figsize=(6, 5))
sns.heatmap(correlation, annot=True, cmap='coolwarm', fmt='.2f', square=True, cbar=True)
plt.title('Correlation Heatmap of Numeric Features')
plt.tight_layout()
plt.show()
